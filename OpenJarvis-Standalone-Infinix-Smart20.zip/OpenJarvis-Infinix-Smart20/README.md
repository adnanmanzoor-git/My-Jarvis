# OpenJarvis Standalone — Infinix Smart 20

An experimental Android-native local AI chat app. It is not an official Stanford OpenJarvis Android port.

## What this version is designed to do

- Build a single Android APK for ARM64 devices.
- Run llama.cpp inside the app through the Android NDK/JNI (no Termux and no separate localhost server).
- Download the quantized model once into the app's private storage; after that, text generation is on-device and can work offline.
- Use a small Qwen2.5-0.5B-Instruct Q4_K_M GGUF model, with a 1,024-token context and two CPU threads as a conservative starting point for a 4 GB RAM phone.

## Important limits

- The APK does not bundle the model weights. On first launch, tap **GET MODEL** and download the model (about 491 MB according to the official Hugging Face repository listing). This avoids making the APK itself very large. After the download, the app does not need a network connection for inference.
- The model is small; response quality, Urdu ability, speed, heat and memory use may be limited. Close other apps and keep the phone cool. If Android closes the app or model loading fails, the phone may not have enough free memory.
- This is a source project. An APK is not included because this workspace does not have Android SDK/NDK and Gradle installed to compile and test it. The GitHub Actions workflow builds the APK in a hosted Android build environment.
- The native build fetches llama.cpp source from its upstream Git repository during the build. The upstream `master` branch can change; if a future build fails, pin the FetchContent `GIT_TAG` to a tested llama.cpp release/commit.

## Build artifact

The workflow is `.github/workflows/build-apk.yml`. It compiles the ARM64 native library and packages it into `app-debug.apk`. The output artifact is named `OpenJarvis-Standalone-Infinix-Smart20`.

## Model source

Model: `Qwen/Qwen2.5-0.5B-Instruct-GGUF`, file `qwen2.5-0.5b-instruct-q4_k_m.gguf`.

Model download URL used by the app:
`https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf`

The model repository identifies the Q4_K_M file as 491 MB and the model is distributed under Apache-2.0. See the model page and license before redistributing model weights.

## App source layout

- `app/src/main/java/ai/openjarvis/mobile/MainActivity.kt` — chat interface, one-time model download, JNI calls.
- `app/src/main/cpp/jarvis_jni.cpp` — native llama.cpp model loading and text generation.
- `app/src/main/cpp/CMakeLists.txt` — native llama.cpp dependency and Android shared library build.
- `.github/workflows/build-apk.yml` — hosted Android APK build workflow.

## Privacy

The app uses internet only for the initial model download. Chat prompts and generated responses are processed by the local native model; this code does not send chat messages to a remote AI API.
