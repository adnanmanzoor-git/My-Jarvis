package ai.openjarvis.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF111F30)
private val Cyan = Color(0xFF48D7F5)
private val Ink = Color(0xFFEAF4FF)
private val Muted = Color(0xFF9FB2C8)
private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf"

data class Message(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp(File(filesDir, "qwen2.5-0.5b-q4.gguf")) }
    }
    override fun onDestroy() { super.onDestroy(); runCatching { LocalLlm.unload() } }
}

object LocalLlm {
    init { System.loadLibrary("openjarvis_native") }
    external fun loadModel(path: String): Boolean
    external fun generate(prompt: String, maxTokens: Int): String
    external fun unload()
}

@Composable
fun JarvisApp(modelFile: File) {
    val messages = remember { mutableStateListOf(Message("assistant", "Hello. I'm Jarvis, your on-device AI assistant. Download the small model once, then chat offline.")) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("On-device AI · model not installed") }
    var downloadProgress by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (modelFile.exists()) {
            status = "Loading on-device model…"
            ready = withContext(Dispatchers.IO) { runCatching { LocalLlm.loadModel(modelFile.absolutePath) }.getOrDefault(false) }
            status = if (ready) "Ready · fully offline" else "Model load failed · download again"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("OPEN JARVIS", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(status, color = Muted, fontSize = 11.sp)
                }
                if (!ready) TextButton(enabled = !busy, onClick = {
                    busy = true; error = ""; status = "Downloading model…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { downloadModel(MODEL_URL, modelFile) { downloadProgress = it } }
                        if (result == null) {
                            val loaded = withContext(Dispatchers.IO) { runCatching { LocalLlm.loadModel(modelFile.absolutePath) }.getOrDefault(false) }
                            ready = loaded
                            status = if (loaded) "Ready · fully offline" else "Model downloaded, but could not load"
                            if (!loaded) error = "This phone could not load the model. Check free storage and restart the app."
                        } else { status = "Download failed"; error = result }
                        busy = false
                    }
                }) { Text("GET MODEL", color = Cyan) }
            }
            if (busy && !ready) LinearProgressIndicator(progress = { downloadProgress / 100f }, modifier = Modifier.fillMaxWidth())
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B9B), modifier = Modifier.padding(horizontal = 16.dp))
            HorizontalDivider(color = Color(0xFF20334A))
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.role == "user") Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 320.dp).background(if (m.role == "user") Color(0xFF15334A) else Panel, RoundedCornerShape(16.dp)).padding(13.dp)) {
                            Text(if (m.role == "user") "YOU" else "JARVIS", color = Cyan, fontSize = 10.sp)
                            Spacer(Modifier.height(5.dp)); Text(m.content, color = Ink, fontSize = 15.sp, lineHeight = 21.sp)
                        }
                    }
                }
                if (busy && ready) item { Text("Jarvis is thinking…", color = Muted) }
            }
            HorizontalDivider(color = Color(0xFF20334A))
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text(if (ready) "Message Jarvis…" else "Install the AI model first…") }, enabled = ready && !busy, maxLines = 4)
                Spacer(Modifier.width(8.dp))
                Button(enabled = ready && input.isNotBlank() && !busy, onClick = {
                    val prompt = input.trim(); input = ""; messages.add(Message("user", prompt)); busy = true
                    scope.launch {
                        val transcript = messages.takeLast(8).joinToString("\n") { if (it.role == "user") "<|im_start|>user\n${it.content}<|im_end|>" else "<|im_start|>assistant\n${it.content}<|im_end|>" }
                        val formatted = "<|im_start|>system\nYou are Jarvis, a helpful assistant. Reply clearly and concisely.\n<|im_end|>\n$transcript\n<|im_start|>assistant\n"
                        val answer = withContext(Dispatchers.IO) { runCatching { LocalLlm.generate(formatted, 180) }.getOrElse { "AI error: ${it.message}" } }
                        messages.add(Message("assistant", answer.ifBlank { "I couldn't generate a response. Please try again." })); busy = false
                    }
                }) { Text("SEND") }
            }
            Text("Model runs on this phone. First download needs internet; chats stay offline.", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 7.dp))
        }
    }
}

private fun downloadModel(url: String, target: File, progress: (Int) -> Unit): String? {
    return try {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".part")
        val connection = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 20000; readTimeout = 60000; instanceFollowRedirects = true }
        connection.connect()
        if (connection.responseCode !in 200..299) throw IllegalStateException("Download server returned HTTP ${connection.responseCode}")
        val total = connection.contentLengthLong
        connection.inputStream.use { input -> temp.outputStream().use { output ->
            val buffer = ByteArray(1024 * 256); var count: Int; var done = 0L
            while (input.read(buffer).also { count = it } >= 0) {
                output.write(buffer, 0, count); done += count
                if (total > 0) progress(((done * 100) / total).toInt().coerceIn(0, 100))
            }
        } }
        connection.disconnect()
        if (temp.length() < 10_000_000) throw IllegalStateException("Downloaded model file is unexpectedly small")
        if (target.exists()) target.delete()
        if (!temp.renameTo(target)) throw IllegalStateException("Could not save model to app storage")
        progress(100); null
    } catch (e: Exception) { e.message ?: "Unknown download error" }
}
